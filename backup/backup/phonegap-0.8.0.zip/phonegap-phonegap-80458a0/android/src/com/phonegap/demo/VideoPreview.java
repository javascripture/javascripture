package com.phonegap.demo;

import android.app.Activity;


public class VideoPreview extends Activity {

}
