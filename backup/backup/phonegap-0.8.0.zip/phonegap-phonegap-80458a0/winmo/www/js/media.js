﻿var media = {
    playSound: function(filename) {
        device.exec("media",[filename]);
    }
};