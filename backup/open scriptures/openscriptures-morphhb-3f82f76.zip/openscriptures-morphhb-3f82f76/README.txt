﻿MorphHB is a project to encode the Westminster Leningrad Codex (WLC)
in OSIS, with Strong numbers assigned to the Hebrew words.  Eventually,
we intend to add morphological parsing information.

The current version, WLC.4.12.zip, in the download section, is released
to the public domain (http://creativecommons.org/licenses/publicdomain/).