Strong's Hebrew Dictionary 1.1 -- 4/6/2010

We are endeavoring to gather the data from the Hebrew dictionary found
in Strong's Concordance, and supplement it with related information.

StrongHebrewG.xml contains the main data.  Typographical errors have 
been corrected, with the original form appearing in a note following 
the element where the change was made.

StrongHebrew.pdf contains the prefatory material from Strong's
dictionary.  It describes the purpose of the dictionary, and defines
the transliteration scheme, and abbreviations used.  There is also a
brief description of the markup used in StrongHebrewG.xml.

PartsOfSpeech.xml contains the descriptions for the part of speech 
codes used.

Dictionary.xslt is a sample style sheet for displaying an entry from 
the dictionary.  It takes two parameters: the first is the Strong 
number for the entry. in the form H1234; teh second is the path to a
CSS style sheet for the display page.